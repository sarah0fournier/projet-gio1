//--------------- Initialisation map avec les fond de la map -----------------

// Projection suisse
const projection = new ol.proj.Projection({
  code: "EPSG:2056",
  units: "m"
});

// Définition de la carte 
var mapView = new ol.View ({
    center: [2660000, 1190000],
    projection :projection,
    zoom: 15,
    extent: [232e4,93e4,30e5,145e4],

});

//--------------- FOND DE CARTE ----------------- 
// Fond WMTS CN a echelle dynamique
const nationalMapCH = new ol.layer.Tile({
  source: new ol.source.TileWMS({
      url: "https://wms.geo.admin.ch/",
      params: { layers: "ch.swisstopo.pixelkarte-farbe" },
      attributions: ["&copy; <a href=\"https://www.geo.admin.ch/fr/home.html\">WMTS CarteNationale / geo.admin.ch</a>"]
  }),
  opacity: 0.6,
  visible : false
});

// Fond WMTS swissImage à échelle dynamique
const swissImage = new ol.layer.Tile({
  source: new ol.source.TileWMS({
    url: "https://wms.geo.admin.ch/",
    params: {layers: "ch.swisstopo.swissimage"},
    attributions: ["&copy; <a href=\"https://www.geo.admin.ch/fr/home.html\">WMTS SWISSIMAGE / geo.admin.ch</a>"]
  }),
  opacity: 0.6,
  visible : false
});

// Fond SwissALTI3D relief multidirectionnel à échelle dynamique
const swissSurface3D = new ol.layer.Tile({
  source: new ol.source.TileWMS({
    url: "https://wms.geo.admin.ch/",
    params: {layers: "ch.swisstopo.swisssurface3d-reliefschattierung-multidirektional"},
    attributions: ["&copy; <a href=\"https://www.geo.admin.ch/fr/home.html\">WMTS Relief multidir. issu de SwissSURFACE3D / geo.admin.ch</a>"]
  }),
  opacity: 0.9,
  visible : false
});

// MO noir et blanc
const MO_nb = new ol.layer.Tile({
  id: "background-layer",
  source: new ol.source.TileWMS({
    url: `https://geodienste.ch/db/av_0/fra?`,
    params: { 'LAYERS': 'LCSF,LCSFPROJ,Conduites,SOLI,SOSF,SOPT,Adresses_des_batiments,Nomenclature,Biens_fonds,Biens_fonds_projetes,Limites_territoriales', 'TILED': true },
    attributions: "Fond de plan &copy; <a href=\"https://geodienste.ch\">geodienste</a>",
  }),
  zIndex: -99,
  visible : false
});

// Restriction drone a l echelle de la suisse
const Restrictions_CH = new ol.layer.Tile({
  source: new ol.source.TileWMS({
    url: "https://wms.geo.admin.ch/",
    projection: 'EPSG:2056',
    params: {
      layers: "ch.bazl.einschraenkungen-drohnen",
      },
    // ???? ATTENTION ATTRIBUTIONS FAUSSE ?????
    attributions: ["Fond de plan &copy; <a href=\"https://www.geo.admin.ch/fr/home.html\">WMTS Relief multidir. issu de SwissSURFACE3D / geo.admin.ch</a>"]
  }),
  opacity: 0.5
});

// Ajout et initialisation de la carte 
var map = new ol.Map ({
    target : 'map',
      view : mapView,
      layers: [nationalMapCH, Restrictions_CH, swissImage, swissSurface3D, MO_nb],
});

// Récupérer l'élément select du fond de carte
var selectFondCarte = document.getElementById('selectFondCarte');

// Ajouter un gestionnaire d'événements pour le changement de sélection
selectFondCarte.addEventListener('change', function() {
    var selectedValue = selectFondCarte.value;

    // Masquer tous les fonds de carte
    nationalMapCH.setVisible(false);
    swissImage.setVisible(false);
    swissSurface3D.setVisible(false);
    MO_nb.setVisible(false);

    // Afficher le fond de carte sélectionné
    if (selectedValue === 'nationalMapCH') {
        nationalMapCH.setVisible(true);
    } else if (selectedValue === 'swissImage') {
        swissImage.setVisible(true);
    } else if (selectedValue === 'swissSurface3D') {
        swissSurface3D.setVisible(true);
    } else if (selectedValue === 'MO_nb') {
        MO_nb.setVisible(true);
    }
});